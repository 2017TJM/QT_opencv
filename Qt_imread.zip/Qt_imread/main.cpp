#include "Qt_imread.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	Qt_imread w;
	w.show();
	return a.exec();
}
