/********************************************************************************
** Form generated from reading UI file 'Qt_imread.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_IMREAD_H
#define UI_QT_IMREAD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Qt_imreadClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *inputLineEdit;
    QPushButton *inputPushButton;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QLineEdit *outputLineEdit;
    QPushButton *outputPushButton;
    QCheckBox *displayImageCheckBox;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *medianBlurRadioButton;
    QRadioButton *gaussianBlurRadioButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Qt_imreadClass)
    {
        if (Qt_imreadClass->objectName().isEmpty())
            Qt_imreadClass->setObjectName(QStringLiteral("Qt_imreadClass"));
        Qt_imreadClass->resize(533, 354);
        centralWidget = new QWidget(Qt_imreadClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        inputLineEdit = new QLineEdit(centralWidget);
        inputLineEdit->setObjectName(QStringLiteral("inputLineEdit"));

        horizontalLayout->addWidget(inputLineEdit);

        inputPushButton = new QPushButton(centralWidget);
        inputPushButton->setObjectName(QStringLiteral("inputPushButton"));

        horizontalLayout->addWidget(inputPushButton);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_3->addWidget(label_2);

        outputLineEdit = new QLineEdit(centralWidget);
        outputLineEdit->setObjectName(QStringLiteral("outputLineEdit"));

        horizontalLayout_3->addWidget(outputLineEdit);

        outputPushButton = new QPushButton(centralWidget);
        outputPushButton->setObjectName(QStringLiteral("outputPushButton"));

        horizontalLayout_3->addWidget(outputPushButton);


        gridLayout->addLayout(horizontalLayout_3, 2, 0, 1, 1);

        displayImageCheckBox = new QCheckBox(centralWidget);
        displayImageCheckBox->setObjectName(QStringLiteral("displayImageCheckBox"));

        gridLayout->addWidget(displayImageCheckBox, 3, 0, 1, 1);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        horizontalLayout_4 = new QHBoxLayout(groupBox);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        medianBlurRadioButton = new QRadioButton(groupBox);
        medianBlurRadioButton->setObjectName(QStringLiteral("medianBlurRadioButton"));

        horizontalLayout_2->addWidget(medianBlurRadioButton);

        gaussianBlurRadioButton = new QRadioButton(groupBox);
        gaussianBlurRadioButton->setObjectName(QStringLiteral("gaussianBlurRadioButton"));

        horizontalLayout_2->addWidget(gaussianBlurRadioButton);


        horizontalLayout_4->addLayout(horizontalLayout_2);


        gridLayout->addWidget(groupBox, 1, 0, 1, 1);

        Qt_imreadClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Qt_imreadClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 533, 23));
        Qt_imreadClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Qt_imreadClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        Qt_imreadClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Qt_imreadClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Qt_imreadClass->setStatusBar(statusBar);

        retranslateUi(Qt_imreadClass);

        QMetaObject::connectSlotsByName(Qt_imreadClass);
    } // setupUi

    void retranslateUi(QMainWindow *Qt_imreadClass)
    {
        Qt_imreadClass->setWindowTitle(QApplication::translate("Qt_imreadClass", "Qt_imread", Q_NULLPTR));
        label->setText(QApplication::translate("Qt_imreadClass", "\350\276\223\345\205\245\345\233\276\347\211\207\357\274\232", Q_NULLPTR));
        inputPushButton->setText(QApplication::translate("Qt_imreadClass", "Browse", Q_NULLPTR));
        label_2->setText(QApplication::translate("Qt_imreadClass", "\350\276\223\345\207\272\345\233\276\347\211\207\357\274\232", Q_NULLPTR));
        outputPushButton->setText(QApplication::translate("Qt_imreadClass", "Browse", Q_NULLPTR));
        displayImageCheckBox->setText(QApplication::translate("Qt_imreadClass", "Display Image After Saving", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("Qt_imreadClass", "Filter Type", Q_NULLPTR));
        medianBlurRadioButton->setText(QApplication::translate("Qt_imreadClass", "Median Blur", Q_NULLPTR));
        gaussianBlurRadioButton->setText(QApplication::translate("Qt_imreadClass", "Gaussian Blur", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Qt_imreadClass: public Ui_Qt_imreadClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_IMREAD_H
