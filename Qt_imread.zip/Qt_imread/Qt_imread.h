#pragma once

#include <QtWidgets/QMainWindow>

#include "ui_Qt_imread.h"
#include <QFileDialog>
#include <QDir>
#include <QFile>
#include <QCloseEvent>
#include <QMessageBox>
#include <QSettings>
#include "opencv2/opencv.hpp"

class Qt_imread : public QMainWindow
{
	Q_OBJECT

public:
	Qt_imread(QWidget *parent = Q_NULLPTR);
protected:
	void closeEvent(QCloseEvent *event);
private slots:
	void on_inputPushButton_pressed();

	void on_outputPushButton_pressed();
private:
	Ui::Qt_imreadClass ui;
	void loadSettings();
	void saveSettings();
};