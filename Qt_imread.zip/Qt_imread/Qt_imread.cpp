#include "Qt_imread.h"

Qt_imread::Qt_imread(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	loadSettings();
}

void Qt_imread::closeEvent(QCloseEvent * event)
{
	int result = QMessageBox::warning(this, "Exit", "Are you sure you want to close this program?", QMessageBox::Yes, QMessageBox::No);
	if (result == QMessageBox::Yes)
	{
		saveSettings();
		event->accept();
	}
}

void Qt_imread::on_inputPushButton_pressed()
{
	QString fileName = QFileDialog::getOpenFileName(this, "Open Input Image", QDir::currentPath(), "Images (*.jpg *.png *.bmp)");
	if (QFile::exists(fileName))
	{
		this->ui.inputLineEdit->setText(fileName);
	}


}

void Qt_imread::on_outputPushButton_pressed()
{
	QString fileName = QFileDialog::getSaveFileName(this, "Select Output Image", QDir::currentPath(), "*.jpg;;*.png;;*.bmp");
	{
		this->ui.outputLineEdit->setText(fileName);
		using namespace cv;
		Mat inpImg, outImg;
		inpImg = imread(this->ui.inputLineEdit->text().toStdString());
		if (this->ui.medianBlurRadioButton->isChecked())
			cv::medianBlur(inpImg, outImg, 5);
		else if (this->ui.gaussianBlurRadioButton->isChecked())
			cv::GaussianBlur(inpImg, outImg, Size(5, 5), 1.25);
		imwrite(fileName.toStdString(), outImg);
		if (this->ui.displayImageCheckBox->isChecked())
			imshow("Output Image", outImg);
	}
}

void Qt_imread::loadSettings()
{
	QSettings settings("Pack", "Hello_OpenCV_Qt", this);
	ui.inputLineEdit->setText(settings.value("inputLineEdit", "").toString());
	ui.outputLineEdit->setText(settings.value("outputLineEdit", "").toString());
	ui.medianBlurRadioButton->setChecked(settings.value("medianBlurRadioButton", true).toBool());
	ui.gaussianBlurRadioButton->setChecked(settings.value("gaussianBlurRadioButton", false).toBool());
	ui.displayImageCheckBox->setChecked(settings.value("displayImageCheckBox", false).toBool());
}

void Qt_imread::saveSettings()
{
	QSettings settings("Pack", "Hello_OpenCV_Qt", this);
	settings.setValue("inputLineEdit", ui.inputLineEdit->text());
	settings.setValue("outputLineEdit", ui.outputLineEdit->text());
	settings.setValue("medianBlurRadioButton", ui.medianBlurRadioButton->isChecked());
	settings.setValue("gaussianBlurRadioButton", ui.gaussianBlurRadioButton->isChecked());
	settings.setValue("displayImageCheckBox", ui.displayImageCheckBox->isChecked());
}
